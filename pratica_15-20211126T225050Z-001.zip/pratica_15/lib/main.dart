import 'package:flutter/material.dart';
import 'package:pratica_15/rota/rota.dart';

void main() => runApp(
      MaterialApp(
        home: PrimeiraRota(),
      ),
    );
