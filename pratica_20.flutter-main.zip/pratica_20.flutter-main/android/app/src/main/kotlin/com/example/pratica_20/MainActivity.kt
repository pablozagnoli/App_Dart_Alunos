package com.example.pratica_20

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
