package com.example.atdv_pratica_18

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
