package com.example.pratica_16_03

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
