package com.example.pratica_23

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
