package com.example.pratica_08_exe03

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
