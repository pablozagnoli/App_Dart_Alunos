package com.example.pratica_22

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
